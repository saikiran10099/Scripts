package com.cg.ems.service;

import java.util.List;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;

public interface EMSService {

	void createTable() throws EMSException;
	void getInsuranceScheme(Employee employee);
	void InsertTable(Employee employee) throws EMSException;
	void UpdateTable(Employee employee) throws EMSException;
	void DeleteData(Employee employee) throws EMSException;
	List<Employee> TableView() throws EMSException;
 }
