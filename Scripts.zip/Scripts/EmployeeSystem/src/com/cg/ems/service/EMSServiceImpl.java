package com.cg.ems.service;

import java.util.List;

import com.cg.ems.dao.EMSDao;
import com.cg.ems.dao.EmsDaoImpl;
import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;

public class EMSServiceImpl implements EMSService{

	EMSDao employeedao= new EmsDaoImpl();
	public void createTable() throws EMSException {
		employeedao.createEmployeeTable();
	}
	@Override
	public void getInsuranceScheme(Employee employee) {
		
		if(employee.getDesignation().equals("System Associate")) {
			if(employee.getSalary()> 5000 && employee.getSalary()<20000) {
				employee.setInsuranceScheme("Scheme C");
			}
		}
		else if(employee.getDesignation().equals("Programmer")) {
			if(employee.getSalary()>=20000 && employee.getSalary() <40000) {
				employee.setInsuranceScheme("Scheme B");
			}
		}
		else if(employee.getDesignation().equals("Manager")) {
			if(employee.getSalary() >=40000) {
				employee.setInsuranceScheme("Scheme A");
			}
		}
		else if(employee.getDesignation().equals("Clerk")) {
			if(employee.getSalary() <5000) {
				employee.setInsuranceScheme("No scheme");
			}
		}
	}
	@Override
	public void InsertTable(Employee employee) throws EMSException {
		
		employeedao.insertEmployeeTable(employee);
	}
	@Override
	public void UpdateTable(Employee employee) throws EMSException {
		
		employeedao.updateEmployeeTable(employee);
	}
	@Override
	public void DeleteData(Employee employee) throws EMSException {
		
		employeedao.deleteEmployeeData(employee);
		
	}
	@Override
	public List<Employee> TableView() throws EMSException {
		
		return employeedao.EmployeeTableView();
	}
}
