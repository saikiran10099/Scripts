package com.cg.ems.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.ems.exception.EMSException;

public class JDBCUtility {
	static File file= null;
	static FileInputStream inputStream=null;
	static Properties properties=null;

	private static Connection connection= null;
	public static Connection getConnection() throws EMSException {
		
		file= new File("resources/jdbc.properties");
		
		try {
			inputStream= new FileInputStream(file);
			properties= new Properties();
			properties.load(inputStream);
			String driver= properties.getProperty("driver");
			String url= properties.getProperty("url");
			String username= properties.getProperty("username");
			String password= properties.getProperty("password");
			
			
			Class.forName(driver);
			connection= DriverManager.getConnection(url, username,password);
			System.out.println("system connected");
		} catch (ClassNotFoundException e) {
			throw new EMSException("problem while loading driver..");
		} catch (SQLException e) {
			throw new EMSException("problem while connecting..");
		} catch (FileNotFoundException e) {
			throw new EMSException("problem with properties file");
		} catch (IOException e) {
			throw new EMSException("problem while loading file");
		}
		
		return connection;
	}
}
