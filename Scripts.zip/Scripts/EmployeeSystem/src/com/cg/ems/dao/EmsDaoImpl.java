package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;
import com.cg.ems.utility.JDBCUtility;

public class EmsDaoImpl implements EMSDao {

	Connection connection= null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet= null;
	@Override
	public void createEmployeeTable() throws EMSException {
		
		connection= JDBCUtility.getConnection();
		try {
			preparedStatement= connection.prepareStatement(QueryMapper.CREATE_TABLE);
			preparedStatement.execute();
		} catch (SQLException e) {
			throw new EMSException("error while creating table "+ e);
		}
		finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				throw new EMSException("problem in closing prepStatement");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new EMSException("problem in closing connection");
			}
			
		}
	}
	@Override
	public void insertEmployeeTable(Employee employee) throws EMSException {
		
		connection= JDBCUtility.getConnection();
		try {
			preparedStatement= connection.prepareStatement(QueryMapper.INSERT_TABLE);
			preparedStatement.setString(1, employee.getName());
			preparedStatement.setDouble(2, employee.getSalary());
			preparedStatement.setString(3, employee.getDesignation());
			preparedStatement.setString(4, employee.getInsuranceScheme());
			//preparedStatement.setString(5, employee.getInsuranceScheme());
			preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			throw new EMSException("error while inserting data"+e);
		}		
	}
	@Override
	public void updateEmployeeTable(Employee employee) throws EMSException {
		
		connection= JDBCUtility.getConnection();
		try {
			preparedStatement= connection.prepareStatement(QueryMapper.UPDATE_TABLE);
			preparedStatement.setDouble(1, employee.getSalary());
			preparedStatement.setString(2, employee.getDesignation());
			preparedStatement.setString(3, employee.getInsuranceScheme());
			preparedStatement.setLong(4, employee.getId());
			preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			throw new EMSException("error while updating");
		}
		
		
	}
	@Override
	public void deleteEmployeeData(Employee employee) throws EMSException {
		connection= JDBCUtility.getConnection();
		try {
			preparedStatement= connection.prepareStatement(QueryMapper.DELETE_DATA);
			preparedStatement.setLong(1, employee.getId());
			preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			throw new EMSException("error while deleting");
			
		}

	
}
	@Override
	public List<Employee> EmployeeTableView() throws EMSException {
		List<Employee> employees= new ArrayList<Employee>();
		connection= JDBCUtility.getConnection();
		
		try {
			preparedStatement= connection.prepareStatement(QueryMapper.TABLE_VIEW);
			resultSet= preparedStatement.executeQuery();
			while(resultSet.next()) {
				long emp_id= resultSet.getLong("emp_id");
				String emp_name= resultSet.getString("emp_name");
				double emp_salary= resultSet.getDouble("emp_salary");
				String emp_desig= resultSet.getString("emp_desig");
				String emp_insurance_scheme= resultSet.getString("emp_insurance_scheme");
				
				Employee employee= new Employee(emp_id, emp_name, emp_salary, emp_desig, emp_insurance_scheme);
				employees.add(employee);
				
			}
			return employees;
			
		} catch (SQLException e) {
			throw new EMSException("error while retrieving");
			
		}
		
	}
}
