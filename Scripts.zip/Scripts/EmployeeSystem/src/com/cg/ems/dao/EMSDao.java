package com.cg.ems.dao;

import java.util.List;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;

public interface EMSDao {

	void createEmployeeTable() throws EMSException;
	void insertEmployeeTable(Employee employee) throws EMSException;
	void updateEmployeeTable(Employee employee) throws EMSException;
	void deleteEmployeeData(Employee employee) throws EMSException;
	List<Employee> EmployeeTableView() throws EMSException;
}
