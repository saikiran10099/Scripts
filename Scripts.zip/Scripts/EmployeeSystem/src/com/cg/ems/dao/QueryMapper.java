package com.cg.ems.dao;

public interface QueryMapper {

	String CREATE_TABLE= "CREATE TABLE employee_details(emp_id number primary key, emp_name varchar2(20), emp_salary number, emp_desig varchar2(20), emp_insurance_scheme varchar2(20))";
	String INSERT_TABLE= "INSERT INTO employee_details VALUES(employee_id.nextval,?,?,?,?)";
	String UPDATE_TABLE= "UPDATE employee_details SET emp_salary= ?, emp_desig= ?,emp_insurance_scheme=? WHERE emp_id = ?";
	String DELETE_DATA=" DELETE FROM employee_details WHERE emp_id= ?";
	String TABLE_VIEW= "SELECT * FROM employee_details";
}
