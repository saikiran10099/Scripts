package com.cg.ems.Main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;
import com.cg.ems.service.EMSService;
import com.cg.ems.service.EMSServiceImpl;

public class UIInterface {
	

	public static void main(String[] args) {
		EMSService emsService= new EMSServiceImpl();
		Employee employee;
		List<Employee> employees= new ArrayList<Employee>();
		Scanner scanner;
		boolean flag= true;
		while(flag) {
		scanner= new Scanner(System.in);
		System.out.println("Enter choice");
		System.out.println("1.create table \n 2. insert into table \n 3. update salary and designation \n 4. delete data \n 5. View Table");
		int choice= scanner.nextInt();
		
		
		switch(choice) {
		
		case 1: 
			try {
				emsService.createTable();
				System.out.println("Table created");
			} catch (EMSException e) {
				System.err.println(e.getMessage());
			}
			break;
			
		case 2:
			System.out.println("Enter employee details");
			/*System.out.println("Enter id");
			long employee_id=scanner.nextInt();*/
			scanner.nextLine();
			System.out.println("Enter name");
			String employee_name= scanner.nextLine();
			System.out.println("Enter salary");
			double employee_salary= scanner.nextDouble();
			scanner.nextLine();
			System.out.println("Enter designaton");
			String employee_desig= scanner.nextLine();
			employee= new Employee(employee_name, employee_salary, employee_desig);
			emsService.getInsuranceScheme(employee);
			
			try {
				emsService.InsertTable(employee);
			} catch (EMSException e) {
				System.err.println(e.getMessage());
			}
			break;
			
		case 3:
			System.out.println("Enter employee id");
			long employee_id= scanner.nextLong();
			scanner.nextLine();
			System.out.println("Enter Salary");
			employee_salary= scanner.nextDouble();
			scanner.nextLine();
			System.out.println("Enter designation");
			employee_desig= scanner.nextLine();
			
			employee= new Employee(employee_id, employee_salary, employee_desig);
			emsService.getInsuranceScheme(employee);
			try {
				emsService.UpdateTable(employee);
			} catch (EMSException e) {
				System.err.println(e.getMessage());
			}
			break;
			
		case 4:
			System.out.println("Enter employee id");
			employee_id= scanner.nextLong();
			
			employee= new Employee(employee_id);
			
			try {
				emsService.DeleteData(employee);
			} catch (EMSException e) {
				System.err.println(e.getMessage());
			}
			break;
			
		case 5:
			try {
				employees= emsService.TableView();
				for(Employee employee1: employees) {
					System.out.println(employee1);
				}
			} catch (EMSException e) {
				System.err.println(e.getMessage());
			}
			break;
			
		}
		System.out.println("Do you wish to continue? True/False");
		flag= scanner.nextBoolean();
		}
	}
}
