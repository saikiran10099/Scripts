package com.cg.bms.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.bms.exceptions.BMSException;
import com.cg.bms.model.Account;

public class BMSService {

	List<Account> list = new ArrayList<>();

	public boolean validateAccountNumber(long accountNumber) throws BMSException {
		boolean result = false;
		String accNumberRegEx = "\\d{10}";
		if (Pattern.matches(accNumberRegEx, String.valueOf(accountNumber))) {
			result = true;
		} else {
			throw new BMSException("account number should contain exactly 10 digits");
		}
		return result;
	}

	public boolean validateAccountType(String accountType) throws BMSException {

		boolean result = false;
		String accountTypeRegEx = "savings|current";

		if (Pattern.matches(accountTypeRegEx, accountType)) {
			result = true;
		} else {
			throw new BMSException("account type should be savings or current");
		}
		return result;
	}

	public boolean validateCustomerName(String customerName) throws BMSException {

		boolean result = false;
		String customerNameRegEx = "[A-Z]{1}[a-zA-Z\\s]{5,19}";

		if (Pattern.matches(customerNameRegEx, customerName)) {
			result = true;
		} else {
			throw new BMSException(
					"first letter should be capital and length in between 6 to 20 & special chars are not allowed");
		}
		return result;
	}

	public boolean validateEmail(String email) throws BMSException {

		boolean result = false;
		String emailRegEx = "[a-zA-Z0-9._-]+@[a-zA-Z]+[.][a-zA-Z]+";

		if (Pattern.matches(emailRegEx, email)) {
			result = true;
		} else {
			throw new BMSException("please neter email id in proper format");
		}
		return result;

	}

	public boolean validateMobile(long mobileNo) throws BMSException {

		boolean result = false;
		String mobileRegEx = "[6-9]{1}[0-9]{9}";

		if (Pattern.matches(mobileRegEx, String.valueOf(mobileNo))) {
			result = true;
		} else {
			throw new BMSException("mobile number should be 10 digits");
		}
		return result;

	}

	public void addAccountDetails(Account account) {

		list.add(account);
	}

	public List<Account> getAllAccounts() {
		return list;
	}

	public Account getAccountDetialsById(long accountNumber) throws BMSException {

		Account accountDetails = null;
		boolean data = false;

		Iterator<Account> iterator = list.iterator();
		while (iterator.hasNext()) {
			Account account = iterator.next();
			if (account.getAccountNumber() == accountNumber) {
				accountDetails = account;
				data = true;
				break;
			}
		}
		if (data == false) {
			throw new BMSException("no account present with the given number");
		}

		return accountDetails;
	}
}
