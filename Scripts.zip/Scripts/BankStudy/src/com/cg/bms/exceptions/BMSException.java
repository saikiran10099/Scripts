package com.cg.bms.exceptions;

public class BMSException extends Exception {

	public BMSException(String message) {
		super(message);
	}
}
