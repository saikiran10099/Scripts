package com.cg.bms.model;

public class Account {

	private long accountNumber;
	private String accountType;
	private String customerName;
	private String email;
	private long mobileNo;

	public Account() {
		// TODO Auto-generated constructor stub
	}

	public Account(long accountNumber, String accountType, String customerName, String email, long mobileNo) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.customerName = customerName;
		this.email = email;
		this.mobileNo = mobileNo;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountType=" + accountType + ", customerName="
				+ customerName + ", email=" + email + ", mobileNo=" + mobileNo + "]";
	}

}
