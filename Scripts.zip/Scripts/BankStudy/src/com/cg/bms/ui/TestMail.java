package com.cg.bms.ui;

import java.util.regex.Pattern;

public class TestMail {

	public static void main(String[] args) {

		String email = "abc.asd_asd@gmail.com";

		String regEx = "[a-zA-Z0-9._-]+@[a-zA-Z]+[.][a-zA-Z]+";

		System.out.println(Pattern.matches(regEx, email));

		int a[] = { 1, 2, 3, 4, 5, 6 };
		int l = a.length - 1;

		while (l >= 0) {
			System.out.println(a[l]);
			l--;
		}

	}

}
