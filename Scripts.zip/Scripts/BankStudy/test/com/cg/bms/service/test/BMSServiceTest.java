package com.cg.bms.service.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bms.exceptions.BMSException;
import com.cg.bms.model.Account;
import com.cg.bms.service.BMSService;

public class BMSServiceTest {

	BMSService service = null;

	@Before
	public void setUp() throws Exception {
		service = new BMSService();
	}

	@After
	public void tearDown() throws Exception {
		service = null;
	}

	@Test
	public void testValidateAccountNumber() {

		long accNo = 3456789012l;
                  boolean result =false;
		try {
			service.validateAccountNumber(accNo);
                  result = true;
			assertEquals(true, result);
		} catch (BMSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testValidateAccountType() {
		String accType = "saving";
		boolean result = false;
		try {
			result = service.validateAccountType(accType);
		} catch (BMSException e) {
			assertEquals(true, result);
		}
	}

	@Test
	public void testValidateCustomerName() {

	}

	@Test
	public void testValidateEmail() {

	}

	@Test
	public void testValidateMobile() {

	}

	@Test
	public void testAddAccountDetails() {

		Account account = new Account(1234567890, "savings", "Pavan kumar", "pavanW@gmail.com", 9533359076l);

		boolean resul = service.addAccountDetails(account);//asserttrue(result);

		assertTrue(resul);

	}

	@Test
	public void testGetAllAccounts() {
		
		Account account1 = new Account(1234567890, "savings", "Pavan kumar", "pavanW@gmail.com", 9533359076l);
		Account account2 = new Account(1234567890, "savings", "Pavan kumar", "pavanW@gmail.com", 9533359076l);
		
		List<Account> list = new ArrayList<>();
		list.add(account1);
		list.add(account2);
/*List<Account> list = service.getAllAccounts();  above 5 steps is not required
		assertnull(list);*/
		
		List<Account> list2 = service.getAllAccounts();
		assertEquals(2, list2.size());
		
	}

	@Test
	public void testGetAccountDetialsById() {
try{
Account account = service.getAccountDetailsById(12345678900);
assertEquals();
		
	}

}
