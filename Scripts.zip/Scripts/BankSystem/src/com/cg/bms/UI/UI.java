package com.cg.bms.UI;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.Random;

import com.cg.bms.Exceptions.BMSException;
import com.cg.bms.model.Account;
import com.cg.bms.service.BMSService;

public class UI {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		BMSService service = new BMSService();

		String inputChoice = "";

		do {

			System.out.println("*** welcome to My Bank *** ");
			System.out.println("1.create account");
			System.out.println("2.display all accounts");
			System.out.println("3.get account details by account number");
			System.out.println("4.exit");

			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice:");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					long accountNumber = 0;
					boolean accountNumberFlag = false;

					switch (choice) {

					case 1:

						/*do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Account number");
							try {
								accountNumber = scanner.nextLong();
								service.validateAccountNumber(accountNumber);
								accountNumberFlag = true;
							} catch (InputMismatchException e) {
								accountNumberFlag = false;
								System.err.println("account number should contain only digits");
							} catch (BMSException e) {
								accountNumberFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!accountNumberFlag);*/

						String accountType = "";
						boolean accountTypeFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter account type");
							accountType = scanner.next();
							try {
								service.validateAccountType(accountType);
								accountTypeFlag = true;
							} catch (BMSException e) {
								accountTypeFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!accountTypeFlag);

						String customerName = "";
						boolean customerNameFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter customer name");
							customerName = scanner.nextLine();
							try {
								service.validateCustomerName(customerName);
								customerNameFlag = true;
							} catch (BMSException e) {
								customerNameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!customerNameFlag);

						String email = "";
						boolean emailFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Email id");
							email = scanner.next();
							try {
								service.validateEmail(email);
								emailFlag = true;
							} catch (BMSException e) {
								emailFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!emailFlag);

						long mobileNo = 0;
						boolean mobileNoFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Mobile number");
							try {
								mobileNo = scanner.nextLong();
								service.validateMobile(mobileNo);
								mobileNoFlag = true;
							} catch (InputMismatchException e) {
								mobileNoFlag = false;
								System.err.println("mobile number should contain only digits");
							} catch (BMSException e) {
								mobileNoFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!mobileNoFlag);

						Account account = new Account(accountType, customerName, email, mobileNo);
						

						service.addAccountDetails(account);
						if(account.getAccountNumber()>0)
						{
							System.out.println("account number generated is"+account.getAccountNumber());
						}
						else
						{
							System.out.println("Account Number not created");
						}

						break;

					case 2:
						System.out.println("in case..");
						List<Account> list = service.getAllAccounts();
						for(Account accountDetails : list) {
							System.out.println(accountDetails);
						}

						break;

					case 3:
						
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Account number");
							try {
								accountNumber = scanner.nextLong();
								service.validateAccountNumber(accountNumber);
								accountNumberFlag = true;
								
								Account accountData = service.getAccountDetialsById(accountNumber);
								System.out.println(accountData);
								
							} catch (InputMismatchException e) {
								accountNumberFlag = false;
								System.err.println("account number should contain only digits");
							} catch (BMSException e) {
								accountNumberFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!accountNumberFlag);

						break;

					case 4:
						System.exit(1);

						break;

					default:
						System.out.println("input should be in the range of 1-4");
						choiceFlag = false;
						break;
					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("input should contaon only digits");
				}
			} while (!choiceFlag);

			System.out.println("do u want to continue again(yes/no)");
			inputChoice = scanner.next();
		} while (inputChoice.equals("yes"));

		scanner.close();

	}

}
