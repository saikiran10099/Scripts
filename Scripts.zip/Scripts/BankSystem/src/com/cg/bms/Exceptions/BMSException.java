package com.cg.bms.Exceptions;

public class BMSException extends Exception{
	public BMSException(String message) {
		super(message);
	}
	
}
