package com.cg.bms.service.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BMSServiceTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testValidateAccountNumber() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateAccountType() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateCustomerName() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateEmail() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateMobile() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddAccountDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAllAccounts() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAccountDetialsById() {
		fail("Not yet implemented");
	}

}
